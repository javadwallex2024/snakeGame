import {useEffect, useState} from "react";
const cellSize = 25
function App() {
  const [isGameOver, setIsGameOver] = useState(false)

  const [snakeX, setSnakeX] = useState(0)
  const [snakeY, setSnakeY] = useState(0)

  const [foodX, setFoodX] = useState(Math.floor(Math.random() * cellSize))
  const [foodY, setFoodY] = useState(Math.floor(Math.random() * cellSize))

  const [foodIsEaten, setFoodIsEaten] = useState(false)

  const [lastKey, setLastKey] = useState('ArrowRight')

  const generateFood = ()=>{
    setFoodX(Math.floor(Math.random() * cellSize))
    setFoodY(Math.floor(Math.random() * cellSize))
    setFoodIsEaten(false)
  }
  const moveSnake = (key: string) => {
      switch(key){
          case 'ArrowUp':
              if(lastKey !== 'ArrowDown') {
                  setLastKey('ArrowUp')
                  if(snakeY === 0)
                      setIsGameOver(true)
                  else
                  setSnakeY((prev) => prev - 1)
              }
              break
          case 'ArrowDown':
              if(lastKey !== 'ArrowUp') {
                  setLastKey('ArrowDown')
                  if(snakeY === cellSize - 1)
                      setIsGameOver(true)
                  else
                  setSnakeY((prev) => prev + 1)
              }
              break
          case 'ArrowLeft':
              if(lastKey !== 'ArrowRight') {
                  setLastKey('ArrowLeft')
                  if(snakeX === 0)
                      setIsGameOver(true)
                  else
                  setSnakeX((prev) => prev - 1)
              }
              break
          case 'ArrowRight':
              if(lastKey !== 'ArrowLeft') {
                  setLastKey('ArrowRight')
                  if(snakeX === cellSize - 1)
                      setIsGameOver(true)
                  else
                  setSnakeX((prev) => prev + 1)
              }
              break
      }
  }

  useEffect(()=>{
    const interval = setInterval(() => {
        if(isGameOver){
            alert('Game Over!')
            clearInterval(interval)
        }else
            moveSnake(lastKey)
    }, 200)
    return () => clearInterval(interval)
  },[lastKey, moveSnake, isGameOver])

  useEffect(()=>{
      if(foodIsEaten){
          generateFood()
      }
  },[foodIsEaten])
  useEffect(()=>{
    const handleKeyDown = (e: KeyboardEvent) => {
        moveSnake(e.key)
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  })
  useEffect(()=>{
    document.querySelectorAll('div').forEach((el) => {
      const x = parseInt(el.getAttribute('aria-x') as string)
      const y = parseInt(el.getAttribute('aria-y') as string)
      if(snakeX === foodX && snakeY === foodY){
        setFoodIsEaten(true)
      }
      if(x === snakeX && y === snakeY){
        el.style.backgroundColor = 'blue'
      }else if(el.style.backgroundColor !== 'red'){
        el.style.backgroundColor = (x + y) % 2 ? 'lawngreen' : 'green'
      }
    })
  },[snakeX, snakeY])
  useEffect(()=>{
   document.querySelectorAll('div').forEach((el) => {
      const x = parseInt(el.getAttribute('aria-x') as string)
      const y = parseInt(el.getAttribute('aria-y') as string)
      if(x === foodX && y === foodY){
        el.style.backgroundColor = 'red'
      }
    })
  }, [foodX, foodY])
  return (
      <section style={{width: '500px', height: '500px', backgroundColor: 'white', margin: 'auto'}}>
        <div style={{display: 'grid', gridTemplateColumns: `repeat(${cellSize}, 1fr)`}}>
          {Array.from({length: cellSize * cellSize}).map((_, index) => {
            const x = index % cellSize
            const y = Math.floor(index / cellSize)
            return <div aria-x={x} aria-y={y}  key={index} style={{width: '20px', height: '20px', backgroundColor: index % 2 ? 'lawngreen' : 'green'}}/>
          })}
        </div>
      </section>
  )
}

export default App
