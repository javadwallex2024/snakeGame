import {useEffect, useState} from "react";
const cellSize = 25
function App() {
  const [isGameOver, setIsGameOver] = useState(false)
  const [snakePositions, setSnakePositions] = useState([{x: 0, y: 0}])
  const [lastKey, setLastKey] = useState('ArrowRight')

  const [foodX, setFoodX] = useState(Math.floor(Math.random() * cellSize))
  const [foodY, setFoodY] = useState(Math.floor(Math.random() * cellSize))
    const generateFood = ()=>{
    const newFoodX = Math.floor(Math.random() * cellSize)
    const newFoodY = Math.floor(Math.random() * cellSize)

    setFoodX(newFoodX)
    setFoodY(newFoodY)
    }
    const moveSnake = (key: string) => {
        const newSnakePositions = [...snakePositions]
        const head = newSnakePositions[newSnakePositions.length - 1]
        let newHead:{x: number, y: number} = {x: head.x, y: head.y}
        switch(key){
            case 'ArrowUp':
                if(lastKey !== 'ArrowDown') {
                    setLastKey('ArrowUp')
                    newHead = {x: head.x, y: head.y - 1}
                }
                break

            case 'ArrowDown':
                if(lastKey !== 'ArrowUp') {
                    setLastKey('ArrowDown')
                    newHead = {x: head.x, y: head.y + 1}
                }
                break
            case 'ArrowLeft':
                if(lastKey !== 'ArrowRight') {
                    setLastKey('ArrowLeft')
                    newHead = {x: head.x - 1, y: head.y}
                }
                break
            case 'ArrowRight':
                if(lastKey !== 'ArrowLeft') {
                    setLastKey('ArrowRight')
                    newHead = {x: head.x + 1, y: head.y}
                }
                break
        }
        if(newHead.x === -1 || newHead.x === cellSize || newHead.y === -1 || newHead.y === cellSize || newSnakePositions.some((pos) => pos.x === newHead.x && pos.y === newHead.y)){
            setIsGameOver(true)
            return
        }
        if(newHead.x === foodX && newHead.y === foodY){
            newSnakePositions.push(newHead)
            generateFood()
        } else {
            newSnakePositions.shift()
            newSnakePositions.push(newHead)
        }
        setSnakePositions(newSnakePositions)
    }
    useEffect(()=>{
        document.querySelectorAll('div').forEach((el) => {
            const x = parseInt(el.getAttribute('aria-x') as string)
            const y = parseInt(el.getAttribute('aria-y') as string)
            if(x === foodX && y === foodY){
                el.style.backgroundColor = 'red'
            }
        })
    }, [foodX, foodY])
    useEffect(()=>{
        document.querySelectorAll('div').forEach((el) => {
            const x = parseInt(el.getAttribute('aria-x') as string)
            const y = parseInt(el.getAttribute('aria-y') as string)
            if(el.style.backgroundColor !== 'red'){
                el.style.backgroundColor = (x + y) % 2 ? 'lawngreen' : 'green'
            }
        })
        document.querySelectorAll('div').forEach((el) => {
            const x = parseInt(el.getAttribute('aria-x') as string)
            const y = parseInt(el.getAttribute('aria-y') as string)
            if(snakePositions.some((pos) => pos.x === x && pos.y === y)){
                el.style.backgroundColor = 'blue'
            }
        })
    }, [snakePositions])
    useEffect(()=>{
        const handleKeyDown = (e: KeyboardEvent) => {
            moveSnake(e.key)
        }
        window.addEventListener('keydown', handleKeyDown)
        return () => window.removeEventListener('keydown', handleKeyDown)
    })
    useEffect(()=>{
        if(isGameOver){
            alert('Game Over!')
        }
    }, [isGameOver])
    useEffect(()=>{
        const interval = setInterval(() => {
            if(isGameOver){
                alert('Game Over!')
                clearInterval(interval)
            }else
                moveSnake(lastKey)
        }, 200)
        return () => clearInterval(interval)
    },[lastKey, moveSnake, isGameOver])
  return (
      <section style={{width: '500px', height: '500px', backgroundColor: 'white', margin: 'auto'}}>
        <div style={{display: 'grid', gridTemplateColumns: `repeat(${cellSize}, 1fr)`}}>
          {Array.from({length: cellSize * cellSize}).map((_, index) => {
            const x = index % cellSize
            const y = Math.floor(index / cellSize)
            return <div aria-x={x} aria-y={y}  key={index} style={{width: '20px', height: '20px', backgroundColor: index % 2 ? 'lawngreen' : 'green'}}/>
          })}
        </div>
      </section>
  )
}

export default App
