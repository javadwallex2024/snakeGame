export function initial(){
    const gameBoardEl = document.getElementById('game-board') as HTMLCanvasElement
    const ctx = gameBoardEl.getContext('2d') as CanvasRenderingContext2D
    for(let i = 0; i < 25; i++){
        for(let j = 0; j < 25; j++){
            ctx.fillStyle = j % 2 ? 'lawngreen' : 'green'
            ctx.fillRect(i * 20, j * 20, 20, 20)
        }
    }


}